#!/bin/bash

gcc -o asc2bin.exe asc2bin.c
gcc -o font.exe font.c
gcc -o make4bitbin.exe make4bitbin.c
g++ -o normtables.exe normtables.c
gcc -o vgm2x16opm.exe vgm2x16opm.c
